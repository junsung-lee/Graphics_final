# Graphics_final
Final Project

The information about this data visualization project is listed on the webpages. We have four visualization modes, in addition to an animated simulation. There is also a sound feature.

The Data: we have included two .csv files in the "data" folder of this repository. However, these were cleaned from the raw datasets. To view more information about those raw datasets, follow the Google Drive links in the "Project Info" section. Additionally, we included the Jupyter Notebook files we used to clean the data. We cleaned the data using the Pandas library in Python.

Use the menu navigation to view different information.
